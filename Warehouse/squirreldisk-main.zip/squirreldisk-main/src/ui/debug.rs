//! Developer hooks driven by environment variables (used for automated
//! screenshots while developing; inert otherwise).
//!
//! * `SQD_SCAN=<path>`       start scanning a folder at launch
//! * `SQD_SHOT=<prefix>`     save screenshots as `<prefix>-<n>.bmp`
//! * `SQD_SHOT_AT=3,8`       seconds after launch at which to shoot
//! * `SQD_MODAL=settings|settings-end|ssh|sshauth|rclone|delete` open a modal before shooting
//! * `SQD_COLLECT=2`         collect the N biggest children of the root
//! * `SQD_QUIT=1`            quit after the last screenshot
//! * `SQD_FULLSCREEN=1`      go full screen at launch
//! * `SQD_ZOOM=2`           draw everything twice as big (sharp screenshots
//!   on a 1x display, with `SQD_WINDOW` twice the usual size)
//! * `SQD_SCREEN=dupes`      open the duplicate finder; `SQD_DUPES_PICK=1` shows
//!   made-up results, opening the biggest set; `SQD_DUPES=<folder>,<folder>`
//!   compares these, and `SQD_DUPES_SELECT=1` opens the biggest set once done
//! * `SQD_UPDATE=available|downloading|ready` fake an update, to see the button
//!   and the update window; `SQD_UPDATE_NOTES=<file>` gives its release notes

use super::app::{App, Modal, Target};
use eframe::egui;
use std::path::PathBuf;

#[derive(Default)]
pub struct Debug {
    shots: Vec<f64>,
    prefix: Option<String>,
    taken: usize,
    started: bool,
    pending: bool,
    modal_done: bool,
    collect_done: bool,
}

impl Debug {
    pub fn from_env() -> Self {
        let shots = std::env::var("SQD_SHOT_AT")
            .ok()
            .map(|s| s.split(',').filter_map(|x| x.trim().parse().ok()).collect())
            .unwrap_or_else(|| vec![3.0]);
        Debug { shots, prefix: std::env::var("SQD_SHOT").ok(), ..Default::default() }
    }
}

impl App {
    pub fn debug_hooks(&mut self, ctx: &egui::Context) {
        if let Ok(u) = std::env::var("SQD_UPDATE") {
            use crate::update::{Release, State};
            let notes = std::env::var("SQD_UPDATE_NOTES").ok().and_then(|f| std::fs::read_to_string(f).ok()).unwrap_or_default();
            let release = Release { version: "9.9.9".into(), notes, asset_url: (!self.settings.auto_install).then(String::new) };
            *self.updater.latest.lock().unwrap() = Some(release.clone());
            *self.updater.state.lock().unwrap() = match u.as_str() {
                "available" => State::Available(release),
                "downloading" => State::Downloading,
                _ => State::Ready("9.9.9".into()),
            };
        }
        if !self.debug.started {
            self.debug.started = true;
            if let Some(z) = std::env::var("SQD_ZOOM").ok().and_then(|z| z.parse::<f32>().ok()) {
                ctx.set_zoom_factor(z);
            }
            if std::env::var("SQD_SCREEN").as_deref() == Ok("dupes") {
                if std::env::var_os("SQD_DUPES_PICK").is_some() {
                    self.dupes = Some(super::dupes::DupesUi::mock());
                }
                self.open_dupes();
                if let Some(d) = self.dupes.as_mut() {
                    if std::env::var_os("SQD_DUPES_PICK").is_some() {
                        d.debug_pick();
                    }
                    // SQD_DUPES=<folder>,<folder>: compare these
                    if let Ok(list) = std::env::var("SQD_DUPES") {
                        for p in list.split(',').filter(|p| !p.is_empty()) {
                            d.add_place(super::dupes::place_for(&Target::Folder(PathBuf::from(p))));
                        }
                        d.start();
                    }
                }
            }
            if std::env::var_os("SQD_FULLSCREEN").is_some() {
                ctx.send_viewport_cmd(egui::ViewportCommand::Fullscreen(true));
            }
            if let Ok(p) = std::env::var("SQD_SCAN") {
                if let Some(v) = self.volumes.iter().find(|v| v.mount == p).cloned() {
                    self.start_session(Target::Volume(v));
                } else {
                    self.start_session(Target::Folder(PathBuf::from(p)));
                }
            }
        }
        if !self.debug.collect_done {
            if let (Ok(n), Some(s)) = (std::env::var("SQD_COLLECT"), self.sessions.first_mut()) {
                if s.progress.is_done() {
                    self.debug.collect_done = true;
                    let n: usize = n.parse().unwrap_or(1);
                    let kids: Vec<u32> = s.tree.read().unwrap().sorted_children(0).into_iter().take(n).collect();
                    for k in kids {
                        s.collect(k);
                    }
                    // Test-only auto delete, restricted to fake folders.
                    let fake = std::env::var("SQD_SCAN").map(|p| p.contains("sqd-fake")).unwrap_or(false);
                    if fake && std::env::var("SQD_AUTODELETE").is_ok() {
                        self.open_delete_confirm(0);
                        if let Some(Modal::ConfirmDelete { items, .. }) = self.modal.take() {
                            self.start_delete(0, items, crate::delete::Mode::Permanent);
                        }
                    }
                }
            } else if std::env::var("SQD_COLLECT").is_err() {
                self.debug.collect_done = true;
            }
        }
        if std::env::var_os("SQD_DUPES_SELECT").is_some() {
            if let Some(d) = self.dupes.as_mut().filter(|d| !d.is_scanning() && d.selected.is_none()) {
                d.debug_pick();
            }
        }
        let Some(prefix) = self.debug.prefix.clone() else { return };
        if self.debug.modal_done && std::env::var("SQD_MODAL").as_deref() == Ok("settings-end") {
            self.settings_scroll = f32::MAX; // clamped to the end once the height is known
        }
        if !self.debug.modal_done && self.time > self.debug.shots.first().copied().unwrap_or(3.0) - 1.0 {
            self.debug.modal_done = true;
            match std::env::var("SQD_MODAL").as_deref() {
                Ok("settings") => self.open_modal(Modal::Settings),
                Ok("settings-end") => self.open_modal(Modal::Settings),
                Ok("languages") => {
                    self.open_modal(Modal::Settings);
                    self.lang_picker = true;
                    super::app::install_fonts(ctx, crate::i18n::current(), true);
                }
                Ok("ssh") => self.open_modal(Modal::Ssh { host: String::new(), path: "/".into() }),
                Ok("sshauth") => self.open_modal(Modal::SshAuth { host: "user@server".into(), path: "/".into(), secret: String::new(), retry: false }),
                Ok(m) if m.starts_with("cloud") => {
                    let kind = m.trim_start_matches("cloud").trim_start_matches(':');
                    self.open_modal(Modal::CloudAccount(Box::new(super::cloud::AccountForm::with_provider(kind, &[]))))
                }
                Ok("rclone") => {
                    self.open_modal(Modal::Rclone { path: String::new(), confirm_remove: None });
                    // SQD_RCLONE_INSTALL=1 presses "Install rclone" right away
                    if std::env::var_os("SQD_RCLONE_INSTALL").is_some() {
                        self.rclone_install = Some(crate::rclone::install(ctx.clone()));
                    }
                }
                Ok("dupes-delete") => self.open_modal(Modal::DupesConfirm { ack: false, permanent: true }),
                Ok("dupes-menu") => {
                    if let Some(d) = self.dupes.as_mut() {
                        d.trash_menu = true;
                    }
                }
                Ok("delete") => {
                    if !self.sessions.is_empty() {
                        self.open_delete_confirm(0)
                    }
                }
                _ => {}
            }
        }
        // collect screenshot replies
        let images: Vec<std::sync::Arc<egui::ColorImage>> = ctx.input(|i| {
            i.raw
                .events
                .iter()
                .filter_map(|e| if let egui::Event::Screenshot { image, .. } = e { Some(image.clone()) } else { None })
                .collect()
        });
        for img in images {
            let path = format!("{prefix}-{}.bmp", self.debug.taken);
            let _ = write_bmp(&path, &img);
            let _ = std::process::Command::new("sips").args(["-s", "format", "png", &path, "--out", &path.replace(".bmp", ".png")]).output();
            let _ = std::fs::remove_file(&path);
            self.debug.taken += 1;
            if self.debug.taken >= self.debug.shots.len() && std::env::var("SQD_QUIT").is_ok() {
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            }
        }
        let requested = self.debug.shots.iter().filter(|t| self.time >= **t).count();
        if requested > self.debug.taken && requested <= self.debug.shots.len() && !self.debug.pending {
            ctx.send_viewport_cmd(egui::ViewportCommand::Screenshot(Default::default()));
            self.debug.pending = true;
        }
        if self.debug.taken == requested {
            self.debug.pending = false;
        }
        ctx.request_repaint();
    }
}

fn write_bmp(path: &str, img: &egui::ColorImage) -> std::io::Result<()> {
    let (w, h) = (img.size[0] as u32, img.size[1] as u32);
    let data_len = w * h * 4;
    let mut out = Vec::with_capacity(54 + data_len as usize);
    out.extend_from_slice(b"BM");
    out.extend_from_slice(&(54 + data_len).to_le_bytes());
    out.extend_from_slice(&[0; 4]);
    out.extend_from_slice(&54u32.to_le_bytes());
    out.extend_from_slice(&40u32.to_le_bytes());
    out.extend_from_slice(&(w as i32).to_le_bytes());
    out.extend_from_slice(&(-(h as i32)).to_le_bytes());
    out.extend_from_slice(&1u16.to_le_bytes());
    out.extend_from_slice(&32u16.to_le_bytes());
    out.extend_from_slice(&[0; 24]);
    for p in &img.pixels {
        out.extend_from_slice(&[p.b(), p.g(), p.r(), 255]);
    }
    std::fs::write(path, out)
}
