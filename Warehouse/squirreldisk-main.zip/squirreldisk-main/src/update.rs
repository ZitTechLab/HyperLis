//! Self-update from GitHub releases.
//!
//! Release assets are expected to be named `squirreldisk-<target-triple>` (plus
//! `.exe` on Windows), as produced by `.github/workflows/release.yml`.

use std::io::Read;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};

pub use crate::GITHUB_REPO;

pub fn current_target() -> &'static str {
    if cfg!(all(target_os = "macos", target_arch = "aarch64")) {
        "aarch64-apple-darwin"
    } else if cfg!(target_os = "macos") {
        "x86_64-apple-darwin"
    } else if cfg!(all(windows, target_arch = "aarch64")) {
        "aarch64-pc-windows-msvc"
    } else if cfg!(windows) {
        "x86_64-pc-windows-msvc"
    } else if cfg!(target_arch = "aarch64") {
        "aarch64-unknown-linux-gnu"
    } else {
        "x86_64-unknown-linux-gnu"
    }
}

#[derive(Clone, Debug)]
pub struct Release {
    pub version: String,
    /// The release's description on GitHub, as Markdown.
    pub notes: String,
    pub asset_url: Option<String>,
}

#[derive(Clone, Debug)]
pub enum State {
    Idle,
    Checking,
    UpToDate,
    Available(Release),
    Downloading,
    Ready(String),
    Failed(String),
}

pub struct Updater {
    pub state: Arc<Mutex<State>>,
    pub downloaded: Arc<AtomicU64>,
    pub total: Arc<AtomicU64>,
    /// The newer release last found, kept while it downloads and installs.
    pub latest: Arc<Mutex<Option<Release>>>,
}

/// A line of release notes, ready to show.
#[derive(Debug, PartialEq)]
pub enum Note {
    Heading(String),
    /// A list item: its opening words in bold, if any, and the rest.
    Bullet(String, String),
    Text(String),
}

/// Release notes as plain lines: what is new, without the Markdown marks and
/// without the sections on how to download and first open the app.
pub fn notes(markdown: &str) -> Vec<Note> {
    // `[text](url)` becomes text; emphasis and code marks go
    fn plain(s: &str) -> String {
        let mut out = String::new();
        let mut rest = s;
        while let Some(open) = rest.find('[') {
            let link = rest[open..].find("](").and_then(|mid| rest[open + mid..].find(')').map(|end| (open + mid, open + mid + end)));
            match link {
                Some((mid, end)) => {
                    out.push_str(&rest[..open]);
                    out.push_str(&rest[open + 1..mid]);
                    rest = &rest[end + 1..];
                }
                None => break,
            }
        }
        out.push_str(rest);
        // (the bundled fonts have no arrow)
        out.replace("**", "").replace("__", "").replace('`', "").replace('→', ">").trim().to_string()
    }
    let mut lines = Vec::new();
    for line in markdown.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with("```") || line.starts_with("![") || line.starts_with("<!--") {
            continue;
        }
        if let Some(h) = line.strip_prefix('#') {
            let h = plain(h.trim_start_matches('#'));
            if matches!(h.to_lowercase().as_str(), "downloads" | "download" | "first launch" | "install" | "installation") {
                break;
            }
            lines.push(Note::Heading(h));
        } else if let Some(item) = ["- ", "* ", "+ "].iter().find_map(|m| line.strip_prefix(m)) {
            let lead = item.strip_prefix("**").and_then(|r| r.split_once("**"));
            lines.push(match lead {
                Some((lead, rest)) => Note::Bullet(plain(lead), plain(rest)),
                None => Note::Bullet(String::new(), plain(item)),
            });
        } else if !line.to_lowercase().contains("full changelog") {
            lines.push(Note::Text(plain(line)));
        }
    }
    lines
}

#[derive(serde::Deserialize)]
struct GhRelease {
    tag_name: String,
    #[serde(default)]
    body: String,
    #[serde(default)]
    draft: bool,
    #[serde(default)]
    prerelease: bool,
    #[serde(default)]
    assets: Vec<GhAsset>,
}

#[derive(serde::Deserialize)]
struct GhAsset {
    name: String,
    browser_download_url: String,
}

/// When running from an AppImage, the path of the .AppImage file (set by the
/// AppImage runtime). The executable itself lives on a read-only mount, so
/// updates replace this file instead.
pub fn appimage_path() -> Option<std::path::PathBuf> {
    std::env::var_os("APPIMAGE").map(std::path::PathBuf::from).filter(|p| p.is_file())
}

fn appimage_asset() -> &'static str {
    if cfg!(target_arch = "aarch64") {
        "SquirrelDisk-aarch64.AppImage"
    } else {
        "SquirrelDisk-x86_64.AppImage"
    }
}

/// Compares dotted versions numerically ("2.10.0" > "2.9.3").
pub fn is_newer(candidate: &str, current: &str) -> bool {
    let parse = |s: &str| -> Vec<u64> {
        s.trim_start_matches('v').split(['.', '-']).map(|p| p.parse().unwrap_or(0)).collect()
    };
    let (a, b) = (parse(candidate), parse(current));
    for i in 0..a.len().max(b.len()) {
        let (x, y) = (a.get(i).copied().unwrap_or(0), b.get(i).copied().unwrap_or(0));
        if x != y {
            return x > y;
        }
    }
    false
}

impl Updater {
    pub fn new() -> Self {
        Updater {
            state: Arc::new(Mutex::new(State::Idle)),
            downloaded: Arc::new(AtomicU64::new(0)),
            total: Arc::new(AtomicU64::new(0)),
            latest: Arc::new(Mutex::new(None)),
        }
    }

    pub fn state(&self) -> State {
        self.state.lock().unwrap().clone()
    }

    pub fn check(&self, ctx: eframe::egui::Context) {
        let (st, latest) = (self.state.clone(), self.latest.clone());
        *st.lock().unwrap() = State::Checking;
        std::thread::spawn(move || {
            let r = (|| -> Result<State, String> {
                let url = format!("https://api.github.com/repos/{GITHUB_REPO}/releases/latest");
                let mut resp = ureq::get(&url)
                    .header("User-Agent", concat!("SquirrelDisk/", env!("CARGO_PKG_VERSION")))
                    .header("Accept", "application/vnd.github+json")
                    .call()
                    .map_err(|e| e.to_string())?;
                let rel: GhRelease = resp.body_mut().read_json().map_err(|e| e.to_string())?;
                if rel.draft || rel.prerelease || !is_newer(&rel.tag_name, env!("CARGO_PKG_VERSION")) {
                    return Ok(State::UpToDate);
                }
                let want = format!("squirreldisk-{}", current_target());
                let asset = rel
                    .assets
                    .iter()
                    .find(|a| {
                        if appimage_path().is_some() {
                            a.name == appimage_asset()
                        } else {
                            a.name == want || a.name == format!("{want}.exe")
                        }
                    })
                    .map(|a| a.browser_download_url.clone());
                Ok(State::Available(Release {
                    version: rel.tag_name.trim_start_matches('v').to_string(),
                    notes: rel.body,
                    asset_url: asset,
                }))
            })();
            if let Ok(State::Available(release)) = &r {
                *latest.lock().unwrap() = Some(release.clone());
            }
            *st.lock().unwrap() = r.unwrap_or_else(State::Failed);
            ctx.request_repaint();
        });
    }

    pub fn install(&self, rel: Release, ctx: eframe::egui::Context) {
        let Some(url) = rel.asset_url.clone() else {
            *self.state.lock().unwrap() = State::Failed("no build for this platform in the release".into());
            return;
        };
        let (st, dl, total) = (self.state.clone(), self.downloaded.clone(), self.total.clone());
        *st.lock().unwrap() = State::Downloading;
        std::thread::spawn(move || {
            let r = (|| -> Result<(), String> {
                let resp = ureq::get(&url)
                    .header("User-Agent", concat!("SquirrelDisk/", env!("CARGO_PKG_VERSION")))
                    .call()
                    .map_err(|e| e.to_string())?;
                total.store(resp.body().content_length().unwrap_or(0), Ordering::Relaxed);
                let mut reader = resp.into_body().into_reader();
                let appimage = appimage_path();
                // Download next to the AppImage so the final rename is atomic.
                let tmp = match &appimage {
                    Some(p) => p.with_file_name(format!(".squirreldisk-update-{}.AppImage", std::process::id())),
                    None => std::env::temp_dir().join(format!("squirreldisk-update-{}", std::process::id())),
                };
                let mut f = std::fs::File::create(&tmp).map_err(|e| e.to_string())?;
                let mut buf = vec![0u8; 64 * 1024];
                loop {
                    let n = reader.read(&mut buf).map_err(|e| e.to_string())?;
                    if n == 0 {
                        break;
                    }
                    std::io::Write::write_all(&mut f, &buf[..n]).map_err(|e| e.to_string())?;
                    dl.fetch_add(n as u64, Ordering::Relaxed);
                    ctx.request_repaint();
                }
                drop(f);
                if std::fs::metadata(&tmp).map(|m| m.len()).unwrap_or(0) < 1_000_000 {
                    return Err("downloaded file looks broken".into());
                }
                #[cfg(unix)]
                {
                    use std::os::unix::fs::PermissionsExt;
                    let _ = std::fs::set_permissions(&tmp, std::fs::Permissions::from_mode(0o755));
                }
                match &appimage {
                    Some(target) => {
                        if let Err(e) = std::fs::rename(&tmp, target) {
                            let _ = std::fs::remove_file(&tmp);
                            return Err(format!("can't replace {}: {e}", target.display()));
                        }
                    }
                    None => {
                        self_replace::self_replace(&tmp).map_err(|e| e.to_string())?;
                        let _ = std::fs::remove_file(&tmp);
                    }
                }
                Ok(())
            })();
            *st.lock().unwrap() = match r {
                Ok(()) => State::Ready(rel.version.clone()),
                Err(e) => State::Failed(e),
            };
            ctx.request_repaint();
        });
    }
}

/// Relaunches the (updated) executable and exits.
pub fn restart() {
    if let Some(appimage) = appimage_path() {
        let _ = std::process::Command::new(appimage).spawn();
        std::process::exit(0);
    }
    if let Ok(exe) = std::env::current_exe() {
        // Inside a macOS bundle, relaunch the .app so it keeps its Dock identity.
        let bundle = exe.ancestors().find(|p| p.extension().is_some_and(|e| e == "app")).map(|p| p.to_path_buf());
        match bundle {
            Some(app) if cfg!(target_os = "macos") => {
                let _ = std::process::Command::new("open").arg("-n").arg(app).spawn();
            }
            _ => {
                let _ = std::process::Command::new(exe).spawn();
            }
        }
    }
    std::process::exit(0);
}

#[cfg(test)]
mod tests {
    #[test]
    fn release_notes_become_plain_lines() {
        use super::{notes, Note};
        let md = "## App 2.6\n\n- **Faster scans.** Now with `--fresh`, see [the docs](https://x.y/z) → here.\n* plain item\n\nA [link](https://a.b) and **bold**.\n**Full Changelog**: https://github.com/a/b/compare/1...2\n\n### Downloads\n- **macOS:** the dmg\n";
        assert_eq!(
            notes(md),
            [
                Note::Heading("App 2.6".into()),
                Note::Bullet("Faster scans.".into(), "Now with --fresh, see the docs > here.".into()),
                Note::Bullet(String::new(), "plain item".into()),
                Note::Text("A link and bold.".into()),
            ]
        );
        assert!(notes("").is_empty());
    }

    #[test]
    fn versions() {
        assert!(super::is_newer("v2.1.0", "2.0.9"));
        assert!(super::is_newer("2.10.0", "2.9.0"));
        assert!(!super::is_newer("2.0.0", "2.0.0"));
        assert!(!super::is_newer("1.9", "2.0.0"));
    }
}
